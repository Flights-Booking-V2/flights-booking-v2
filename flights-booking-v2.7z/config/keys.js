module.exports = {
    mongoURI:  "mongodb+srv://user_shortLink:A123A123@cluster0-51n2q.mongodb.net/flybooking",
    secretOrKey: 'DontTellAnyBody'
};
